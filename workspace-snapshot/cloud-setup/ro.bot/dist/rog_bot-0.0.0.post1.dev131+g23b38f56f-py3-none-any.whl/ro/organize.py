"""정리(분류·이름): 폴더 최상위 파일을 규칙·키워드로 분류하고 새 이름을 제안한 뒤, 승인한 항목만 옮긴다.

원칙 (docs/ORGANIZE-DESIGN.md, docs/CLEANUP-DESIGN.md)
- scan은 읽기 전용이다. 계획(~/.ro/cleanup/plan.json)만 쓴다. 파일 본문은 로컬에서 앞부분만 읽고 저장하지 않는다.
  외부 엔진으로는 아무것도 보내지 않는다(로컬 LLM 단계 L3는 아직 없음).
- 분류: L1 확장자·이름 패턴 → L2 키워드(파일 이름·문서 앞부분). 확신도가 낮으면 '검토 필요'로만 표시하고 옮기지 않는다.
- apply는 id나 카테고리를 직접 지정해야 하고 영구 삭제는 없다. 되돌림 로그(journal.jsonl)로 undo한다.
- 제외: 숨김·비밀 이름·민감 이름(복구 코드·OTP·시드, 내용도 읽지 않음)·심볼릭 링크·하위 폴더·다운로드 중·최근 10분 내 수정·iCloud 자리표시 파일.
- 파일마다 행동은 하나(docs/CLEANUP-DESIGN.md): move(분류 폴더로 이동) · quarantine(치울 후보) · keep(보관).
  판정 순서는 공용 탐지기(ro/detect.py)의 완전 중복 → 풀린 압축 원본 → 옛 버전 → 분류. 하위 폴더는 남길 쪽으로만 쓰인다.
  재무·계약·서류는 옛 버전·오래됨 이유로 치우지 않는다(완전 중복은 검토 필요로만). 오래됨은 태그이고 --stale일 때만 치울 후보.
- apply는 치울 후보를 먼저 ~/.ro/cleanup/trash/<batch>/로 격리하고(남길 쪽이 같은 배치에서 먼저 옮겨지지 않게) 그다음 이동한다.
  기록은 ~/.ro/cleanup/journal.jsonl 하나에 남기고, undo는 예전 organize·tidy 기록의 배치도 되돌린다.

  ro organize scan [--root ~/Downloads] [--stale [--stale-days 180]]
  ro organize show [--action move|quarantine|keep] [--kind extracted] [--category 재무] [--review]
  ro organize edit ID [--category 문서] [--name "전세 계약서"] | --action keep|move|quarantine
  ro organize apply ID [ID...] | --category 재무 | --kind extracted
  ro organize undo [BATCH] | status
  ro organize trash [--empty [--older 7d]]   격리 폴더 보기 / N일 지난 배치 영구 삭제(터미널에서 yes 확인)
"""
import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import time
import unicodedata
import zipfile
from collections import Counter
from pathlib import Path
from urllib.parse import unquote

from . import detect, fsutil, log, tidy
from .mapper import is_secret
from .detect import norm_key as _k, sha256 as _sha
from .tidy import check_root

HOME = "~/.ro"
ROOT = "~/Downloads"
DEST_ROOT = "~/Documents/정리됨"
MIN_CONFIDENCE = 0.6
RECENT_SECONDS = 600
TEXT_MAX = 2048
TITLE_MAX = 40
PARTIAL = (".crdownload", ".part", ".download", ".icloud", ".tmp")

CATEGORIES = ("문서", "재무", "계약·서류", "학습·자료", "표·데이터", "이미지", "이미지/스크린샷",
              "웹페이지", "압축·설치", "기타")
EXT_CATEGORY = {
    **dict.fromkeys((".pdf", ".docx", ".doc", ".hwp", ".hwpx", ".rtf", ".txt", ".md", ".pages",
                     ".pptx", ".ppt", ".key", ".odt"), "문서"),
    **dict.fromkeys((".xlsx", ".xls", ".csv", ".tsv", ".numbers"), "표·데이터"),
    **dict.fromkeys((".png", ".jpg", ".jpeg", ".heic", ".gif", ".webp", ".svg", ".bmp", ".tiff"), "이미지"),
    **dict.fromkeys((".html", ".htm", ".webarchive", ".mhtml"), "웹페이지"),
    **dict.fromkeys((".zip", ".7z", ".rar", ".tar", ".gz", ".tgz", ".dmg", ".pkg"), "압축·설치"),
}
SCREENSHOT = re.compile(r"^(screenshot|screen shot|스크린샷|화면 기록|cleanshot)", re.I)
# L2: 문서 계열만 키워드로 세분한다. 이름에 있으면 2점, 본문에 있으면 1점(키워드당 1회).
KEYWORDS = {
    "재무": ("영수증", "청구서", "견적서", "세금계산서", "거래명세", "납부", "결제", "인보이스", "원천징수",
           "연말정산", "급여명세", "송금", "invoice", "receipt", "billing"),
    "계약·서류": ("계약서", "약정", "신청서", "증명서", "동의서", "확인서", "위임장", "등본", "지원서", "이력서",
              "자기소개서", "서약서", "contract", "agreement", "certificate", "resume"),
    "학습·자료": ("논문", "강의", "연구", "초록", "발표자료", "학회", "abstract", "references",
              "lecture", "thesis", "journal", "proceedings"),
}
ACTIONS = ("move", "quarantine", "keep")
QUARANTINE_KINDS = ("duplicate", "extracted", "version", "stale")
IMPORTANT = ("재무", "계약·서류")  # 옛 버전·오래됨 이유로는 치우지 않는 종류
# 표·이미지처럼 키워드 세분을 하지 않는 파일도 이름이 이렇다면 같은 보호를 받는다(예: "KCC 경비 내역.xlsx")
IMPORTANT_EXTRA = ("경비", "정산", "결산", "재무", "회계", "미수금", "세금", "예산", "영수")
STALE_DAYS = 180
DATED = ("재무", "계약·서류")  # 문서 안의 날짜가 의미 있는 종류만 본문 날짜를 쓴다(나머지는 받은 날짜)
JUNK_TITLE = re.compile(r"^(?:(?:untitled|제목\s*없음|document|download|file|scan|img|image|slide|"
                        r"powerpoint(?:\s*프레젠테이션)?)[\s\d-]*$|microsoft\s+\w+\s*-)", re.I)
BAD_CHARS = re.compile(r'[/\\:*?"<>|\x00-\x1f\x7f]')
LONG_DIGITS = re.compile(r"\d{6,}")  # 계좌·주민번호 의심 숫자열은 이름에 남기지 않는다
COPY_MARK = re.compile(r"(\s*\(\d+\)|\s*사본|\s+copy)+\s*$", re.I)  # "(1) (1)"처럼 겹친 사본 표시까지
# 복구·백업 코드, OTP, 지갑 시드처럼 보이는 파일은 목록에서 빼고 내용도 읽지 않는다(원칙 2)
SENSITIVE = re.compile(r"recovery|backup[-_ ]?codes?|mnemonic|복구\s*코드|니모닉|시드\s*구문"
                       r"|(?<![a-z])(otp|2fa|seed)(?![a-z])", re.I)
NAME_DATE = re.compile(r"(?<!\d)(20\d\d)[-._년 ]?\s?(\d{1,2})[-._월 ]?\s?(\d{1,2})일?(?!\d)")
NAME_MONTH = re.compile(r"(?<!\d)(20\d\d)[-._년 ]\s?(0?[1-9]|1[0-2])월?(?![\d.])")  # invoice_2026_09
VERSION_TAIL = re.compile(r"\s(?:v\d+(?:\.\d+)*|final|최종|\d+\.\d+(?:\.\d+)*)\b.*$", re.I)
CAMERA = re.compile(r"^(?:img|dsc|dscn|pxl|mvimg|gopr|dji)[\s-]?\d{3,5}$", re.I)  # 카메라 번호는 그 자체가 이름
TEXT_DATE = re.compile(r"(?<!\d)(20\d\d)\s?(?:[-./]|년)\s?(\d{1,2})\s?(?:[-./]|월)\s?(\d{1,2})(?!\d)")


# ---------- 본문 추출(로컬, 앞부분만) ----------
PDF_JXA = """
function run(argv) {
  ObjC.import('PDFKit');
  var out = [];
  for (var i = 0; i < argv.length; i++) {
    var r = {text: '', title: ''};
    try {
      var d = $.PDFDocument.alloc.initWithURL($.NSURL.fileURLWithPath(argv[i]));
      if (d && !d.isNil()) {
        var n = Math.min(d.pageCount, 2), s = '';
        for (var k = 0; k < n && s.length < %d; k++) {
          var t = d.pageAtIndex(k).string;
          if (t && !t.isNil()) s += ObjC.unwrap(t) + '\\n';
        }
        r.text = s.slice(0, %d);
        var a = d.documentAttributes;
        var ti = (a && !a.isNil()) ? a.objectForKey('Title') : null;
        if (ti && !ti.isNil()) r.title = String(ObjC.unwrap(ti));
      }
    } catch (e) {}
    out.push(r);
  }
  return JSON.stringify(out);
}
""" % (TEXT_MAX, TEXT_MAX)


def _pdf_texts(paths):
    """macOS PDFKit(JXA)로 앞 2쪽 텍스트·제목. 경로는 argv로 넘긴다. 실패하면 빈 값."""
    out = {}
    for i in range(0, len(paths), 40):
        chunk = [str(p) for p in paths[i:i + 40]]
        try:
            r = subprocess.run(["osascript", "-l", "JavaScript", "-e", PDF_JXA, *chunk],
                               capture_output=True, text=True, timeout=120)
            rows = json.loads(r.stdout) if r.returncode == 0 else []
        except (OSError, subprocess.TimeoutExpired, ValueError):
            rows = []
        for p, row in zip(chunk, rows):
            out[p] = (row.get("text", ""), row.get("title", ""))
    return out


def _strip_xml(raw):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", raw)).strip()


def _zip_member(z, name, limit=262144):
    try:
        with z.open(name) as f:
            return f.read(limit).decode("utf-8", errors="replace")
    except KeyError:
        return ""


def _office_text(path):
    """docx·xlsx·pptx·hwpx(zip+XML) → (본문 앞부분, 제목). 압축 폭탄을 피하려 멤버당 256KB까지만 읽는다."""
    try:
        with zipfile.ZipFile(path) as z:
            core = _zip_member(z, "docProps/core.xml")
            m = re.search(r"<dc:title>([^<]*)</dc:title>", core)
            names = z.namelist()
            body = next((n for n in ("word/document.xml", "xl/sharedStrings.xml", "Contents/section0.xml",
                                     "ppt/slides/slide1.xml") if n in names), None)
            return (_strip_xml(_zip_member(z, body))[:TEXT_MAX] if body else ""), (m[1] if m else "")
    except (OSError, zipfile.BadZipFile, RuntimeError):
        return "", ""


def _plain_text(path, limit=65536):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read(limit)
    except OSError:
        return ""


def extract(paths):
    """{경로: (본문 앞부분, 메타데이터 제목)}. 결과는 메모리에서만 쓰고 저장하지 않는다."""
    paths = [Path(p) for p in paths]
    out = _pdf_texts([p for p in paths if p.suffix.lower() == ".pdf"])
    for p in paths:
        ext = p.suffix.lower()
        if ext in (".docx", ".xlsx", ".pptx", ".hwpx"):
            out[str(p)] = _office_text(p)
        elif ext in (".html", ".htm"):
            raw = _plain_text(p)
            m = re.search(r"<title[^>]*>(.*?)</title>", raw, re.I | re.S)
            out[str(p)] = (_strip_xml(raw)[:TEXT_MAX], m[1].strip() if m else "")
        elif ext in (".txt", ".md", ".csv", ".tsv"):
            out[str(p)] = (_plain_text(p, TEXT_MAX), "")
    return out


# ---------- 분류·이름 ----------
def classify(path, text="", title=""):
    """(카테고리, 확신도, 근거 목록)."""
    name, ext = path.name, path.suffix.lower()
    if ext in (".png", ".jpg", ".jpeg", ".heic", ".mov") and SCREENSHOT.match(name):
        return "이미지/스크린샷", 0.95, ["이름이 스크린샷 형식"]
    cat = EXT_CATEGORY.get(ext)
    if cat is None:
        return "기타", 0.4, [f"알 수 없는 확장자 {ext or '(없음)'}"]
    reasons = [f"확장자 {ext}"]
    if cat != "문서":
        return cat, 0.9, reasons
    low_name, low_text = (name + " " + title).lower(), text.lower()
    scores = Counter()
    hits = {}
    for c, words in KEYWORDS.items():
        for w in words:
            if w in low_name:
                scores[c] += 2
                hits.setdefault(c, []).append(f"{w}(이름)")
            elif w in low_text:
                scores[c] += 1
                hits.setdefault(c, []).append(f"{w}(본문)")
    top = scores.most_common(2)
    if top and top[0][1] >= 2:
        if len(top) > 1 and top[1][1] == top[0][1]:
            return "문서", 0.6, reasons + [f"키워드 동률: {top[0][0]}·{top[1][0]}"]
        c = top[0][0]
        return c, (0.9 if any(h.endswith("(이름)") for h in hits[c]) else 0.75), \
            reasons + ["키워드 " + ", ".join(hits[c][:3])]
    return "문서", 0.7 if (text or title) else 0.6, reasons + (["내용 키워드 없음"] if text else ["본문 없음"])


def _valid_date(y, m, d, today):
    try:
        v = datetime.date(int(y), int(m), int(d))
    except ValueError:
        return None
    return v if datetime.date(2000, 1, 1) <= v <= today else None


def pick_date(path, st, category, text="", today=None):
    """이름 속 날짜 > (재무·계약 문서면) 본문 날짜 > 받은 날짜(생성 시각)."""
    today = today or datetime.date.today()
    for m in NAME_DATE.finditer(path.stem):
        if v := _valid_date(*m.groups(), today):
            return v, "이름"
    if category in DATED:
        for m in TEXT_DATE.finditer(text):
            if v := _valid_date(*m.groups(), today):
                return v, "본문"
    for m in NAME_MONTH.finditer(path.stem):
        if v := _valid_date(*m.groups(), 1, today):
            return v, "이름(월)"
    born = getattr(st, "st_birthtime", st.st_mtime)
    return datetime.date.fromtimestamp(born), "받은 날"


def _nfc(s):
    """macOS 파일 이름은 한글이 자모로 분해(NFD)되어 있어 정규식·키워드가 빗나간다."""
    return unicodedata.normalize("NFC", s or "")


def clean_title(raw):
    t = re.sub(r"^filename\*?=(utf-8'[^']*')?", "", _nfc(raw), flags=re.I)  # 헤더째 저장된 다운로드 이름
    if re.search(r"%[0-9A-Fa-f]{2}", t):
        t = _nfc(unquote(t))
    t = NAME_DATE.sub(" ", t)
    t = NAME_MONTH.sub(" ", t)
    t = COPY_MARK.sub("", t)
    t = LONG_DIGITS.sub(" ", BAD_CHARS.sub(" ", t))
    t = re.sub(r"\(\s*\)|\[\s*\]", " ", t)  # 날짜·숫자를 빼고 남은 빈 괄호
    t = re.sub(r"(?<!\d)\.|\.(?!\d)", " ", t)  # 점은 버전 번호(v2.0) 사이에서만 남긴다
    t = re.sub(r"[_\s]+", " ", t).strip(" -_.")
    t = log.redact(t)
    if len(t) > TITLE_MAX and (tail := VERSION_TAIL.search(t)):  # 자를 때도 v3·final 같은 버전 표시는 남긴다
        tail = tail.group(0).strip()[:16]
        t = t[:TITLE_MAX - len(tail) - 1].rstrip() + " " + tail
    return t[:TITLE_MAX].strip()


def _meaningful(t):
    return len(re.findall(r"[A-Za-z가-힣]", t)) >= 2 and not JUNK_TITLE.match(t) \
        and not re.fullmatch(r"[0-9a-f -]{8,}", t, re.I)


def pick_title(path, text="", meta_title=""):
    """파일 이름 > 메타데이터 제목 > 본문 첫 줄. 모두 의미 없으면 '제목없음'."""
    for cand in (path.stem, meta_title):
        t = clean_title(cand or "")
        if _meaningful(t):
            return t
    for line in text.splitlines()[:5]:
        t = clean_title(line)
        if 2 <= len(t) <= TITLE_MAX and _meaningful(t):
            return t
    t = clean_title(path.stem)  # '#2'처럼 짧아도 원래 이름이 '제목없음'보다 낫다(해시·untitled류는 제외)
    if CAMERA.match(t):  # IMG_2041은 사진을 찾는 번호다
        return t
    return t if t and not JUNK_TITLE.match(t) and not re.fullmatch(r"[0-9a-f -]{8,}", t, re.I) else "제목없음"


def _unique(dest, taken):
    stem, ext, n = dest.stem, dest.suffix, 2
    while dest in taken or dest.exists():
        dest = dest.with_name(f"{stem}_{n}{ext}")
        n += 1
    return dest


# ---------- 계획 ----------
def _dir(home):
    return Path(home).expanduser() / "organize"  # 예전 계획 위치(읽기만)


def _candidates(root, dest_root, now, recent=None):
    # 원본을 사본보다 먼저 처리해야 원본이 깔끔한 이름을 받고 사본이 _2를 받는다
    for p in sorted(root.iterdir(), key=lambda x: (bool(COPY_MARK.search(_nfc(x.stem))), x.name)):
        name = p.name
        if name.startswith((".", "~$")) or is_secret(name) or SENSITIVE.search(_nfc(name)) or p.is_symlink() \
                or not p.is_file() or name.lower().endswith(PARTIAL):
            continue
        if dest_root == p or dest_root in p.parents:
            continue
        st = p.stat()
        if now - st.st_mtime < RECENT_SECONDS:
            if recent is not None:
                recent.append(name)
            continue  # 다운로드·편집 중일 수 있다
        yield p, st


def scan(root=ROOT, dest_root=DEST_ROOT, extractor=extract, now=None, today=None, stale=False,
         stale_days=STALE_DAYS):
    """읽기 전용. 반환: 계획 dict(파일은 바꾸지 않는다). 항목마다 action은 move·quarantine·keep 중 하나."""
    root = check_root(root)
    dest_root = Path(dest_root).expanduser().resolve()
    if root == dest_root or dest_root in root.parents:
        raise ValueError(f"정리 결과 폴더 안은 스캔할 수 없습니다: {root}")
    now = now or time.time()
    recent = []
    files = list(_candidates(root, dest_root, now, recent))
    texts = extractor([p for p, _ in files])
    items, taken = [], set()
    for p, st in files:
        text, meta = (_nfc(x) for x in texts.get(str(p), ("", "")))
        named = p.with_name(_nfc(p.name))  # 판단용 이름. 실제 이동은 원래 경로 p로 한다
        cat, conf, reasons = classify(named, text, meta)
        day, why = pick_date(named, st, cat, text, today)
        title = pick_title(named, text, meta)
        prefix = day.strftime("%Y-%m") if why == "이름(월)" else day.isoformat()
        dest = _unique(dest_root / cat / f"{prefix}_{title}{p.suffix.lower()}", taken)
        taken.add(dest)
        items.append({
            "id": hashlib.sha1(f"organize:{p}".encode()).hexdigest()[:8], "path": str(p),
            "size": st.st_size, "mtime": int(st.st_mtime), "sha": _sha(p), "category": cat,
            "dest": str(dest), "confidence": conf, "review": conf < MIN_CONFIDENCE,
            "reasons": reasons + [f"날짜: {why}"], "edited": False,
            "action": "move", "kind": "classified", "keep": None, "tags": []})
    _judge(root, files, items, now, stale, stale_days)
    return {"root": str(root), "dest_root": str(dest_root), "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "items": items, "recent_skipped": len(recent)}


def movable(it):
    """지금 apply로 옮길 수 있는 항목인지(이전 형식 계획은 action이 없어 move로 본다)."""
    return it.get("action", "move") == "move" and not it["review"]


def _important(it):
    """재무·계약 종류이거나 이름에 그런 낱말이 있는 파일(분류와 별개로 보호만 한다)."""
    if it["category"] in IMPORTANT:
        return True
    name = _nfc(Path(it["path"]).name).lower()
    return any(w in name for w in KEYWORDS["재무"] + KEYWORDS["계약·서류"] + IMPORTANT_EXTRA)


def _mark(it, action, kind, reason, keep=None, review=False):
    it.update(action=action, kind=kind, keep=str(keep) if keep else None, review=review)
    it["reasons"] = [reason] + it["reasons"]


def _judge(root, files, items, now, stale, stale_days):
    """분류가 끝난 항목에 치울 후보·보관을 판정한다(파일은 바꾸지 않는다). 한 파일에는 판정 하나만 남는다.
    탐지는 하위 폴더까지 보되 제안은 최상위 후보(items)에만 붙는다."""
    by_key = {_k(i["path"]): i for i in items}
    claimed = set()
    context = list(tidy.walk(root))  # 하위 폴더 포함: 남길 쪽 후보로만 쓰인다
    for keeper, copies, _ in detect.duplicate_groups(context):
        members = [keeper] + [p for p, _ in copies]
        keep = next((m for m in members if m.parent != root), keeper)  # 사용자가 묶어 둔 폴더 안 사본을 남긴다
        claimed.add(_k(keep))
        for m in members:
            it = by_key.get(_k(m))
            if m == keep or it is None:
                continue
            claimed.add(_k(m))
            _mark(it, "quarantine", "duplicate", f"{keep} 와 내용 동일", keep, review=_important(it))
    for p, _ in files:
        it = by_key[_k(p)]
        if _k(p) in claimed or p.suffix.lower() != ".zip":
            continue
        found = detect.extracted(p, root)
        if found:
            base, hits = found
            claimed.add(_k(p))
            claimed.update(_k(h) for h in hits)  # 압축을 치우면 유일한 사본이 되므로 다른 이유로 치우지 않는다
            where = "같은 폴더" if base == p.parent else f"{base.name}/ 폴더"
            _mark(it, "quarantine", "extracted", f"압축 안 파일이 모두 {where}에 풀려 있음(CRC 일치)", base)
    for keeper, olds in detect.version_groups([(p, st) for p, st in files if _k(p) not in claimed]):
        claimed.add(_k(keeper[0]))
        for p, _ in olds:
            it = by_key[_k(p)]
            claimed.add(_k(p))
            if _important(it):
                _mark(it, "keep", "important", f"{keeper[0].name} 의 옛 버전으로 보이지만 재무·계약 관련이라 보관")
            else:
                _mark(it, "quarantine", "version", f"{keeper[0].name} 의 옛 버전", keeper[0])
    for it in items:
        days = int((now - it["mtime"]) / 86400)
        if days <= stale_days:
            continue
        it["tags"].append(f"오래됨 {days}일")
        if stale and it["action"] == "move" and _k(it["path"]) not in claimed and not _important(it):
            _mark(it, "quarantine", "stale", f"{days}일간 수정 없음")


def save_plan(plan, home=HOME):
    fsutil.atomic_write(_cleanup_dir(home) / "plan.json", json.dumps(log.redact(plan), ensure_ascii=False, indent=2))


def load_plan(home=HOME):
    """~/.ro/cleanup/plan.json, 없으면 예전 위치(~/.ro/organize/plan.json). 다음 저장부터 새 위치로 옮겨진다."""
    for path in (_cleanup_dir(home) / "plan.json", _dir(home) / "plan.json"):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            continue
        except (OSError, json.JSONDecodeError):
            break
    raise ValueError("계획이 없습니다. 먼저 `ro organize scan`을 실행하세요.")


def edit(cid, category=None, name=None, home=HOME, log_dir=log.LOG_DIR, action=None):
    """카테고리·이름·행동을 직접 확정한다. 확정한 항목은 '검토 필요'가 풀린다.
    action: keep(그대로 둠) · quarantine(치울 후보, 재무·계약 중복의 확정 포함) · move(분류 폴더로 이동)."""
    plan = load_plan(home)
    it = next((i for i in plan["items"] if i["id"] == cid), None)
    if not it:
        raise ValueError(f"계획에 없는 id: {cid}")
    if category and category not in CATEGORIES:
        raise ValueError(f"카테고리는 다음 중 하나: {', '.join(CATEGORIES)}")
    if action and action not in ACTIONS:
        raise ValueError(f"행동은 다음 중 하나: {', '.join(ACTIONS)}")
    if action in ("keep", "quarantine"):
        if category or name:
            raise ValueError("보관·치울 후보로 바꿀 때는 --category·--name을 함께 쓸 수 없습니다")
        before = it.get("action", "move")
        if action == "keep":
            it.update(action="keep", kind="manual", keep=None)
        elif it.get("kind") not in QUARANTINE_KINDS:
            it.update(action="quarantine", kind="manual", keep=None)  # 직접 지정: 남길 쪽 없이 그 파일만 치운다
        else:
            it["action"] = "quarantine"  # 탐지 근거(kind·keep)는 그대로 두고 확정만 한다
        it.update(review=False, edited=True, confidence=1.0)
        it["reasons"] = [f"직접 {'보관' if action == 'keep' else '치울 후보'}로 지정"] + it["reasons"]
        save_plan(plan, home)
        log.append("organize_edit", f"{before} → {action}", {"from": before, "to": action, "kind": it["kind"]},
                   log_dir=log_dir)
        return it
    if it.get("action", "move") != "move":
        if not category and action != "move":
            raise ValueError("치울 후보·보관 항목은 --category(또는 --action move)로 이동 항목으로 바꿉니다")
        it.update(action="move", kind="classified", keep=None)
    before = it["category"]
    dest = Path(it["dest"])
    ext = Path(it["path"]).suffix.lower()
    stem = dest.stem
    if name:
        t = clean_title(name[:-len(ext)] if ext and name.lower().endswith(ext) else name)
        if not t:
            raise ValueError("이름이 비었습니다")
        stem = t if NAME_DATE.match(t) else f"{stem[:10]}_{t}"
    cat = category or before
    taken = {Path(i["dest"]) for i in plan["items"] if i["id"] != cid}
    it.update(category=cat, dest=str(_unique(Path(plan["dest_root"]) / cat / f"{stem}{ext}", taken)),
              review=False, edited=True, confidence=1.0)
    save_plan(plan, home)
    log.append("organize_edit", f"{before} → {cat}", {"ext": ext, "from": before, "to": cat, "renamed": bool(name)},
               log_dir=log_dir)
    return it


# ---------- 적용·되돌리기 ----------
def _cleanup_dir(home):
    return Path(home).expanduser() / "cleanup"


def _journals(home):
    """새 기록은 cleanup에, 예전 organize·tidy 기록은 읽기·복원 표시만 한다."""
    h = Path(home).expanduser()
    return {"cleanup": h / "cleanup" / "journal.jsonl", "organize": h / "organize" / "journal.jsonl",
            "tidy": h / "tidy" / "journal.jsonl"}


def read_journal(home=HOME):
    """모든 기록(각 항목에 source 표시)을 시간 순으로."""
    out = []
    for source, path in _journals(home).items():
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for line in lines:
            try:
                out.append({**json.loads(line), "source": source})
            except json.JSONDecodeError:
                continue
    out.sort(key=lambda e: e.get("ts", ""))
    return out


def pending(home=HOME, sources=("cleanup", "organize", "tidy")):
    """되돌리지 않은 이동·격리 기록."""
    entries = [e for e in read_journal(home) if e["source"] in sources]
    closed = {(e["source"], e["batch"], e["id"]) for e in entries if e["op"] in ("restore", "purge")}
    return [e for e in entries if e["op"] in ("move", "quarantine")
            and (e["source"], e["batch"], e["id"]) not in closed]  # 비운(purge) 항목은 되돌릴 수 없다


def _append(entry, home, source="cleanup"):
    path = _journals(home)[source]
    fsutil.ensure_dir(path.parent)
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    with os.fdopen(fd, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def apply(ids=(), category=None, kind=None, home=HOME, log_dir=log.LOG_DIR):
    """지정한 id(또는 카테고리의 이동 항목, 종류별 치울 후보)만 처리한다. 치울 후보를 먼저 격리하고 그다음 옮긴다.
    반환: (batch, 적용 목록, 건너뜀 [(id, 이유)])."""
    plan = load_plan(home)
    root = check_root(plan["root"])
    dest_root = Path(plan["dest_root"])
    by_id = {i["id"]: i for i in plan["items"]}
    ids = list(ids)
    cats = [category] if isinstance(category, str) else list(category or ())  # --category를 여러 번 줄 수 있다
    kinds = [kind] if isinstance(kind, str) else list(kind or ())
    ids += [i["id"] for i in plan["items"] if i["category"] in cats and movable(i)]
    ids += [i["id"] for i in plan["items"] if i.get("action") == "quarantine" and i["kind"] in kinds
            and not i["review"]]
    if not ids:
        raise ValueError("적용할 id나 --category·--kind를 지정하세요")
    # 남길 쪽(중복 원본·최신 버전·풀린 파일)이 같은 배치의 이동으로 먼저 사라지지 않게 격리를 앞에 둔다
    ids = sorted(dict.fromkeys(ids), key=lambda c: (by_id.get(c) or {}).get("action") != "quarantine")
    batch = time.strftime("%Y%m%d-%H%M%S")
    trash_root = _cleanup_dir(home) / "trash"
    done, skipped = [], []
    for cid in ids:
        it = by_id.get(cid)
        if not it:
            skipped.append((cid, "계획에 없는 id"))
            continue
        action = it.get("action", "move")
        if action == "keep":
            skipped.append((cid, "보관 항목 — 옮기려면 edit --category로 위치를 정하세요"))
            continue
        if it["review"]:
            skipped.append((cid, "검토 필요 — edit로 카테고리를 확정한 뒤 적용하세요" if action == "move"
                            else "검토 필요(재무·계약 관련 중복) — 확인 후 edit ID --action quarantine로 확정하세요"))
            continue
        src = Path(it["path"])
        try:
            if src.parent.resolve() != root or src.is_symlink() or not src.is_file():
                raise ValueError("루트 최상위의 일반 파일이 아님")
            st = src.stat()
            if st.st_size != it["size"] or int(st.st_mtime) != it["mtime"] or _sha(src) != it["sha"]:
                raise ValueError("계획 이후 파일이 바뀜")
            if action == "quarantine":
                if not detect.kept_ok(it, src, root):
                    raise ValueError("남겨 둔 쪽이 사라지거나 바뀜 — 다시 scan 하세요")
                dst = fsutil.ensure_dir(trash_root / batch) / f"{cid}-{src.name}"
                if dst.exists():
                    raise ValueError("격리 위치가 이미 있음")
                mode = stat.S_IMODE(st.st_mode)  # 격리본은 비공개로 두되 복원 때 원래 권한을 되돌린다
                shutil.move(str(src), str(dst))
                os.chmod(dst, 0o600)
                entry = {"op": "quarantine", "kind": it["kind"], "mode": mode, "trash": str(trash_root)}
            else:
                dst = Path(it["dest"])
                if dest_root.resolve() not in dst.resolve().parents:
                    raise ValueError("정리 폴더 밖으로 가는 경로")
                dst = _unique(dst, set())
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dst))
                entry = {"op": "move", "dest_root": str(dest_root)}
        except (OSError, ValueError) as e:
            skipped.append((cid, str(e)))
            continue
        _append({**entry, "batch": batch, "id": cid, "src": str(src), "dst": str(dst), "sha": it["sha"],
                 "root": str(root), "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z")}, home)
        done.append({**it, "dest": str(dst)})
    if done:
        cats = Counter(i["category"] for i in done if i.get("action", "move") == "move")
        log.append("organize", f"정리 {len(done)}건",
                   {"batch": batch, "count": len(done), "categories": dict(cats),
                    "quarantined": sum(i.get("action") == "quarantine" for i in done)}, log_dir=log_dir)
    return batch, done, skipped


KIND_LABELS = {"duplicate": "중복", "extracted": "풀린 압축", "version": "옛 버전", "stale": "오래됨", "manual": "직접 지정"}


TRASH_DAYS = 7  # 격리 후 이만큼 지난 배치만 비울 수 있다(결정 ③)


def _trash_roots(home):
    h = Path(home).expanduser()
    return {"cleanup": h / "cleanup" / "trash", "tidy": h / "tidy" / "trash"}  # tidy는 예전 격리 위치


def trash_size(home=HOME):
    """격리 폴더에 지금 있는 (파일 수, 바이트). 비우기 전에는 디스크 공간이 줄지 않는다."""
    n = size = 0
    for root in _trash_roots(home).values():
        for p in root.rglob("*"):
            if p.is_file() and not p.is_symlink():
                n, size = n + 1, size + p.stat().st_size
    return n, size


def trash_batches(home=HOME, now=None):
    """격리된 채(되돌리지도 비우지도 않은) 배치 목록, 오래된 순.
    각 항목: source·batch·ts·age_days·entries(기록)·present(남은 파일 수)·bytes."""
    now = now or time.time()
    groups = {}
    for e in pending(home):
        if e["op"] != "quarantine" and e["source"] != "tidy":  # tidy 기록의 move는 격리였다
            continue
        g = groups.setdefault((e["source"], e["batch"]), {"source": e["source"], "batch": e["batch"],
                                                          "ts": e["ts"], "entries": []})
        g["entries"].append(e)
        g["ts"] = min(g["ts"], e["ts"])
    out = []
    for g in groups.values():
        when = datetime.datetime.strptime(g["ts"], "%Y-%m-%dT%H:%M:%S%z").timestamp()
        present = [Path(e["dst"]) for e in g["entries"] if Path(e["dst"]).is_file() and not Path(e["dst"]).is_symlink()]
        g.update(age_days=(now - when) / 86400, present=len(present), bytes=sum(p.stat().st_size for p in present))
        out.append(g)
    return sorted(out, key=lambda g: g["ts"])


def purge(batches, home=HOME, log_dir=log.LOG_DIR):
    """격리 배치를 **영구 삭제**한다(되돌릴 수 없음). 확인 질문은 호출하는 쪽(CLI)이 받는다.
    기록에 있고 격리 폴더 안에 있는 일반 파일만 지운다. 반환: (지운 파일 수, 바이트, 건너뜀 [(id, 이유)])."""
    roots = {k: v.resolve() for k, v in _trash_roots(home).items()}
    n = size = 0
    skipped = []
    for g in batches:
        for e in g["entries"]:
            dst = Path(e["dst"])
            root = roots["tidy"] if e["source"] == "tidy" else Path(e.get("trash") or roots["cleanup"]).resolve()
            try:
                if root not in roots.values() or root not in dst.resolve().parents:
                    raise ValueError("격리 폴더 밖 — 지우지 않음")
                if dst.is_symlink() or (dst.exists() and not dst.is_file()):
                    raise ValueError("일반 파일이 아님 — 지우지 않음")
                if dst.is_file():
                    size += dst.stat().st_size
                    dst.unlink()
                    n += 1
            except (OSError, ValueError) as ex:
                skipped.append((e["id"], str(ex)))
                continue
            _append({"op": "purge", "batch": e["batch"], "id": e["id"], "src": e["src"],
                     "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z")}, home, e["source"])
            for d in dst.parents:  # 비게 된 배치 폴더만 지운다(격리 루트 자체는 남김)
                if d.resolve() == root or root not in d.resolve().parents:
                    break
                try:
                    d.rmdir()
                except OSError:
                    break
    if n:
        log.append("organize_purge", f"격리 비움 {n}건", {"count": n, "bytes": size,
                   "batches": [g["batch"] for g in batches]}, log_dir=log_dir)
    return n, size, skipped


def _check_restorable(e, home):
    """기록 하나를 되돌려도 되는지(원본 위치·격리/정리 위치·내용). 실패하면 ValueError."""
    src, dst = Path(e["src"]), Path(e["dst"])
    if e["op"] == "quarantine" or e["source"] == "tidy":  # tidy 기록의 move는 격리였다
        trash = Path(e.get("trash") or Path(home).expanduser() / "tidy" / "trash").resolve()
        if trash not in dst.resolve().parents or not dst.is_file() or dst.is_symlink():
            raise ValueError("격리본이 없음")
        inside = (src.parent.resolve() == Path(e["root"]).resolve() if e["source"] != "tidy"
                  else Path(e["root"]).resolve() in src.resolve().parents)
        stop = trash
    else:
        stop = Path(e["dest_root"]).resolve()
        if stop not in dst.resolve().parents or not dst.is_file() or dst.is_symlink():
            raise ValueError("정리된 파일이 없음")
        inside = src.parent.resolve() == Path(e["root"]).resolve()
    if not inside:
        raise ValueError("원래 루트 밖")
    if src.exists():
        raise ValueError("원위치에 이미 파일이 있음")
    if _sha(dst) != e["sha"]:
        raise ValueError("정리 후 내용이 바뀜")
    return src, dst, stop


def undo(batch=None, home=HOME, log_dir=log.LOG_DIR):
    """배치(기본: 가장 최근)를 원래 이름·위치로 되돌린다. 이동·격리 모두, 예전 organize·tidy 배치도.
    반환: (batch, 복원 목록, 건너뜀)."""
    todo = pending(home)
    if not todo:
        raise ValueError("되돌릴 항목이 없습니다")
    if batch:
        group = [e for e in todo if e["batch"] == batch]
        if not group:
            raise ValueError(f"되돌릴 수 없는 배치입니다(이미 되돌렸거나 비웠거나 없음): {batch}")
    else:
        last = todo[-1]
        batch, group = last["batch"], [e for e in todo if (e["source"], e["batch"]) == (last["source"], last["batch"])]
    done, skipped = [], []
    for e in group:
        try:
            src, dst, stop = _check_restorable(e, home)
            src.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(dst), str(src))
            if "mode" in e:
                os.chmod(src, e["mode"])
            for d in dst.parents:  # 비게 된 카테고리·배치 폴더만 지운다(정리 루트·격리 루트 자체는 남김)
                if d.resolve() == stop or stop not in d.resolve().parents:
                    break
                try:
                    d.rmdir()
                except OSError:
                    break
        except (OSError, ValueError) as ex:
            skipped.append((e["id"], str(ex)))
            continue
        _append({"op": "restore", "batch": e["batch"], "id": e["id"], "src": e["src"],
                 "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z")}, home, e["source"])  # 원래 기록 쪽에 복원을 남긴다
        done.append(e)
    if done:
        log.append("organize", f"되돌림 {len(done)}건", {"batch": batch, "count": len(done)},
                   log_dir=log_dir)
    return batch, done, skipped


# ---------- CLI ----------
def _mb(n):
    return f"{n / 1048576:.1f}MB" if n >= 1048576 else f"{n / 1024:.0f}KB"


def show(plan, category=None, review=False, action=None, kind=None):
    lines = []
    items = [i for i in plan["items"] if (not category or i["category"] == category) and (not review or i["review"])
             and (not action or i.get("action", "move") == action) and (not kind or i.get("kind") == kind)]
    moves = [i for i in items if i.get("action", "move") == "move"]
    for cat in CATEGORIES:
        group = [i for i in moves if i["category"] == cat]
        if not group:
            continue
        lines.append(f"\n## {cat} ({len(group)})")
        for i in group:
            flag = "검토" if i["review"] else ("확정" if i["edited"] else f"{i['confidence']:.2f}")
            tags = f"  [{', '.join(i['tags'])}]" if i.get("tags") else ""
            lines.append(f"[{i['id']}] {flag:>4}  {Path(i['path']).name}{tags}\n"
                         f"              → {Path(i['dest']).name}   ({'; '.join(i['reasons'])})")
    quarantine = [i for i in items if i.get("action") == "quarantine"]
    if quarantine:
        lines.append(f"\n## 치울 후보 ({len(quarantine)}, {_mb(sum(i['size'] for i in quarantine))})")
        for i in quarantine:
            flag = "검토" if i["review"] else i["kind"]
            lines.append(f"[{i['id']}] {flag:>9}  {Path(i['path']).name}   ({i['reasons'][0]})")
    kept = [i for i in items if i.get("action") == "keep"]
    if kept:
        lines.append(f"\n## 보관 ({len(kept)})")
        for i in kept:
            lines.append(f"[{i['id']}]  {Path(i['path']).name}   ({i['reasons'][0]})")
    all_items = plan["items"]
    n_move = sum(i.get("action", "move") == "move" for i in all_items)
    q = [i for i in all_items if i.get("action") == "quarantine"]
    n_review = sum(i["review"] for i in all_items if i.get("action", "move") == "move")
    lines.append(f"\n이동 {n_move}건 · 치울 후보 {len(q)}건({_mb(sum(i['size'] for i in q))}) · "
                 f"보관 {sum(i.get('action') == 'keep' for i in all_items)}건 · 검토 필요 {n_review}건 · "
                 f"정리 위치 {plan['dest_root']}")
    if plan.get("recent_skipped"):
        lines.append(f"방금({RECENT_SECONDS // 60}분 안에) 받거나 고친 파일 {plan['recent_skipped']}개는 "
                     "다운로드·편집 중일 수 있어 건너뛰었습니다. 잠시 뒤 다시 scan 하세요.")
    return "\n".join(lines)


TIDY_NOTICE = ("`ro tidy`는 `ro organize`로 합쳐졌습니다(이 별칭은 곧 사라집니다). 같은 동작: "
               "ro organize scan --stale · show --action quarantine · apply ID · undo · status. "
               "정리 대상은 이제 폴더 최상위 파일입니다(하위 폴더는 남길 쪽 판단에만 쓰임).")


def tidy_alias(argv=None):
    """예전 `ro tidy` 명령을 organize로 넘긴다(docs/CLEANUP-DESIGN.md 결정 ①)."""
    ap = argparse.ArgumentParser(prog="ro tidy", description="별칭 — ro organize로 합쳐짐. " + TIDY_NOTICE)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan", help="= ro organize scan --stale")
    s.add_argument("--root", default=ROOT)
    s.add_argument("--stale-days", type=int, default=STALE_DAYS)
    s.add_argument("--min-size", type=int, help="무시됨(organize는 크기 하한이 없음)")
    a = sub.add_parser("apply", help="= ro organize apply ID...")
    a.add_argument("ids", nargs="+")
    u = sub.add_parser("undo", help="= ro organize undo [BATCH]")
    u.add_argument("batch", nargs="?")
    sub.add_parser("status", help="= ro organize status")
    args = ap.parse_args(argv)
    print(TIDY_NOTICE, file=sys.stderr)
    if args.cmd == "scan":
        if args.min_size is not None:
            print("--min-size는 무시합니다.", file=sys.stderr)
        return main(["scan", "--root", args.root, "--stale", "--stale-days", str(args.stale_days)])
    if args.cmd == "apply":
        return main(["apply", *args.ids])
    if args.cmd == "undo":
        return main(["undo", *([args.batch] if args.batch else [])])
    return main(["status"])


def main(argv=None):
    ap = argparse.ArgumentParser(prog="ro organize", description="파일 분류·이름 정리 → 승인 후 이동 → 되돌리기")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan", help="읽기 전용 스캔 + 계획 저장")
    s.add_argument("--root", default=ROOT)
    s.add_argument("--dest", default=DEST_ROOT)
    s.add_argument("--stale", action="store_true", help="오래된 파일도 치울 후보로(기본은 태그만)")
    s.add_argument("--stale-days", type=int, default=STALE_DAYS)
    sh = sub.add_parser("show", help="계획 보기")
    sh.add_argument("--category", choices=CATEGORIES)
    sh.add_argument("--review", action="store_true", help="검토 필요 항목만")
    sh.add_argument("--action", choices=ACTIONS, help="이동·치울 후보·보관 중 하나만")
    sh.add_argument("--kind", choices=QUARANTINE_KINDS + ("classified", "important", "manual"))
    e = sub.add_parser("edit", help="카테고리·이름 확정")
    e.add_argument("id")
    e.add_argument("--category", choices=CATEGORIES)
    e.add_argument("--name", help="새 제목(날짜 접두어는 유지, 확장자는 바꾸지 않음)")
    e.add_argument("--action", choices=ACTIONS, help="행동을 직접 정한다(재무·계약 중복은 quarantine으로 확정)")
    a = sub.add_parser("apply", help="지정한 항목만 이동(삭제 없음)")
    a.add_argument("ids", nargs="*")
    a.add_argument("--category", choices=CATEGORIES, action="append", help="이 카테고리의 확정 항목 전부(여러 번 가능)")
    a.add_argument("--kind", choices=("duplicate", "extracted", "version", "stale"), action="append",
                   help="이 종류의 치울 후보 전부(검토 필요 제외, 여러 번 가능)")
    u = sub.add_parser("undo", help="원래 이름·위치로 되돌리기")
    u.add_argument("batch", nargs="?")
    sub.add_parser("status", help="이동·복원 이력")
    tr = sub.add_parser("trash", help="격리 폴더 보기 / N일 지난 배치 비우기(영구 삭제, 터미널 확인)")
    tr.add_argument("--empty", action="store_true", help="--older보다 오래된 배치를 영구 삭제(터미널에서 yes 입력 필요)")
    tr.add_argument("--older", default=f"{TRASH_DAYS}d", help=f"이보다 오래된 배치만(예: 7d, 14d, 최소 1d). 기본 {TRASH_DAYS}d")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "scan":
            plan = scan(args.root, args.dest, stale=args.stale, stale_days=args.stale_days)
            save_plan(plan)
            log.append("organize_scan", f"정리안 {len(plan['items'])}건", {
                "count": len(plan["items"]), "review": sum(i["review"] for i in plan["items"]),
                "categories": dict(Counter(i["category"] for i in plan["items"]))})
            print(show(plan))
            print("아무것도 옮기지 않았습니다. 적용(이동 항목): ro organize apply ID... | --category 카테고리")
        elif args.cmd == "show":
            print(show(load_plan(), args.category, args.review, args.action, args.kind))
        elif args.cmd == "edit":
            if not args.category and not args.name and not args.action:
                raise ValueError("--category·--name·--action 중 하나는 필요합니다")
            it = edit(args.id, args.category, args.name, action=args.action)
            if it["action"] == "move":
                print(f"[{it['id']}] → {it['category']}/{Path(it['dest']).name}")
            else:
                print(f"[{it['id']}] {it['action']} ({it['kind']})")
        elif args.cmd == "apply":
            batch, done, skipped = apply(args.ids, args.category, args.kind)
            for i in done:
                verb = "격리" if i.get("action") == "quarantine" else "→"
                print(f"{Path(i['path']).name} {verb} {i['dest']}")
            print(f"정리 {len(done)}건 (batch {batch}) — 되돌리기: ro organize undo {batch}")
            for cid, why in skipped:
                print(f"건너뜀 [{cid}]: {why}")
        elif args.cmd == "undo":
            batch, done, skipped = undo(args.batch)
            print(f"되돌림 {len(done)}건")
            for cid, why in skipped:
                print(f"건너뜀 [{cid}]: {why}")
        elif args.cmd == "trash":
            trash_cli(args.older, args.empty)
        else:
            for e in read_journal():
                print(f"{e['ts']} {e['op']:10} {e['source']:8} {e['batch']} [{e['id']}] {e['src']}")
    except ValueError as e:
        raise SystemExit(str(e))


def _days(spec):
    m = re.fullmatch(r"(\d+)d?", str(spec).strip())
    if not m or int(m[1]) < 1:
        raise ValueError("--older는 1d 이상(예: 7d)이어야 합니다")
    return int(m[1])


def trash_cli(older=f"{TRASH_DAYS}d", empty=False, home=HOME, log_dir=log.LOG_DIR, stdin=None, stdout=None,
              ask=input):
    """격리 폴더 목록. empty면 기준보다 오래된 배치만, 대화형 터미널에서 yes를 받은 뒤에 영구 삭제한다."""
    stdin, stdout = stdin or sys.stdin, stdout or sys.stdout
    days = _days(older)
    batches = trash_batches(home)
    if not batches:
        print("격리된 파일이 없습니다.")
        return
    for g in batches:
        tag = "  ← 비울 수 있음" if g["age_days"] >= days else ""
        src = " (예전 tidy)" if g["source"] == "tidy" else ""
        print(f"{g['batch']}{src}  {g['age_days']:.0f}일 전 · {g['present']}개 · {_mb(g['bytes'])}{tag}")
    print(f"합계 {sum(g['present'] for g in batches)}개 · {_mb(sum(g['bytes'] for g in batches))} "
          "(되돌리기: ro organize undo BATCH)")
    if not empty:
        print(f"비우기: ro organize trash --empty — {days}일 지난 배치만, 영구 삭제(되돌릴 수 없음)")
        return
    due = [g for g in batches if g["age_days"] >= days]
    if not due:
        print(f"{days}일 지난 배치가 없습니다. 아무것도 지우지 않았습니다.")
        return
    if not (stdin.isatty() and stdout.isatty()):
        raise SystemExit("영구 삭제는 터미널에서 직접 확인해야 합니다(파이프·자동 실행은 거부). 아무것도 지우지 않았습니다.")
    print(f"\n영구 삭제: {len(due)}배치 · {sum(g['present'] for g in due)}개 · {_mb(sum(g['bytes'] for g in due))}. "
          "되돌릴 수 없습니다.")
    try:
        answer = ask("계속하려면 yes를 입력하세요: ")
    except EOFError:
        answer = ""
    if answer.strip() != "yes":
        print("취소했습니다. 아무것도 지우지 않았습니다.")
        return
    n, size, skipped = purge(due, home, log_dir)
    print(f"격리 비움: {n}개 · {_mb(size)} 삭제")
    for cid, why in skipped:
        print(f"건너뜀 [{cid}]: {why}")


if __name__ == "__main__":
    main()
