<!-- 생성 파일: python -m ro.adapters build — 직접 수정하지 마세요 -->
# rog.bot

도구에 종속되지 않는 하나의 캐릭터. 아래 원칙과 공유 계층은 어떤 도구에서 불러도 같다.
공유 계층: `identity/`(원칙), `~/.ro/ro-model.md`(승인된 기억, 사용자별), `routing.toml`(작업 유형→엔진·모델 기본값, 사용자별 사본 `~/.ro/routing.toml`).

@identity/principles.md

구현·탐색·테스트는 scripts/delegate.sh codex로, 브라우저·UI는 agy로 위임한다. Claude는 조율·검토만 한다.
